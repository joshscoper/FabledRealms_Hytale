package net.fabledrealms.fr.lifecycle;

import com.hypixel.hytale.event.EventRegistration;
import com.hypixel.hytale.event.EventRegistry;
import com.hypixel.hytale.logger.HytaleLogger;
import com.hypixel.hytale.server.core.event.events.player.PlayerConnectEvent;
import com.hypixel.hytale.server.core.event.events.player.PlayerDisconnectEvent;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import net.fabledrealms.fr.core.AccountService;
import net.fabledrealms.fr.core.CharacterService;
import net.fabledrealms.fr.identity.AccountIdentity;
import net.fabledrealms.fr.session.PlayerSession;
import net.fabledrealms.fr.session.SessionStore;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

public final class PlayerLifecycleModule implements AutoCloseable {

    private final HytaleLogger logger;
    private final SessionStore sessions;
    private final AccountService accountService;
    private final CharacterService characterService;

    private EventRegistration<Void, PlayerConnectEvent> connectReg;
    private EventRegistration<Void, PlayerDisconnectEvent> disconnectReg;

    public PlayerLifecycleModule(HytaleLogger logger,
                                 SessionStore sessions,
                                 AccountService accountService,
                                 CharacterService characterService) {
        this.logger = logger;
        this.sessions = sessions;
        this.accountService = accountService;
        this.characterService = characterService;
    }

    public void register(EventRegistry events) {
        connectReg = events.register(PlayerConnectEvent.class, this::onConnect);
        disconnectReg = events.register(PlayerDisconnectEvent.class, this::onDisconnect);
        logger.at(Level.INFO).log("[FR] PlayerLifecycleModule registered.");
    }

    private void onConnect(PlayerConnectEvent e) {
        PlayerRef ref = e.getPlayerRef();
        UUID accountId = AccountIdentity.accountIdFrom(ref);

        PlayerSession session = new PlayerSession(ref, accountId);
        sessions.put(session);

        CompletableFuture.runAsync(() -> {
            try {
                accountService.ensureAccount(accountId);
                session.roster(characterService.listSummaries(accountId));
                session.state(PlayerSession.State.READY);
                logger.at(Level.INFO).log("[FR] Session READY: " + ref + " roster=" + session.roster().size());
            } catch (Exception ex) {
                logger.at(Level.SEVERE).log("[FR] Failed to bootstrap session for " + ref, ex);
            }
        });
    }

    private void onDisconnect(PlayerDisconnectEvent e) {
        PlayerRef ref = e.getPlayerRef();
        sessions.remove(ref);
        logger.at(Level.INFO).log("[FR] Session cleared: " + ref);
    }

    @Override
    public void close() {
        try { if (connectReg != null) connectReg.unregister(); } catch (Exception ignored) {}
        try { if (disconnectReg != null) disconnectReg.unregister(); } catch (Exception ignored) {}
        sessions.clear();
    }
}
