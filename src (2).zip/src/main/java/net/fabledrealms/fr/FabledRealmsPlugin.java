package net.fabledrealms.fr;

import com.hypixel.hytale.server.core.plugin.JavaPlugin;
import com.hypixel.hytale.server.core.plugin.JavaPluginInit;
import net.fabledrealms.fr.core.Services;
import net.fabledrealms.fr.persistence.DbConfig;
import net.fabledrealms.fr.persistence.PersistenceService;

import javax.annotation.Nonnull;

public final class FabledRealmsPlugin extends JavaPlugin {

    private final Services services = new Services();
    private PersistenceService persistence;

    public FabledRealmsPlugin(@Nonnull JavaPluginInit init) {
        super(init);
    }

    @Override
    public void start() {
        DbConfig cfg = DbConfig.loadOrCreate();

        persistence = new PersistenceService(getLogger(), cfg);
        persistence.start();

        services.register(Services.class, services);
        services.register(PersistenceService.class, persistence);

        var ds = persistence.dataSource();
        services.register(net.fabledrealms.fr.persistence.repo.CharacterRepository.class,
                new net.fabledrealms.fr.persistence.repo.CharacterRepository(ds));
        services.register(net.fabledrealms.fr.persistence.repo.CharacterSnapshotRepository.class,
                new net.fabledrealms.fr.persistence.repo.CharacterSnapshotRepository(ds));
        services.register(net.fabledrealms.fr.persistence.repo.EconomyLedgerRepository.class,
                new net.fabledrealms.fr.persistence.repo.EconomyLedgerRepository(ds));

        // Build runtime services
        var sessionStore = new net.fabledrealms.fr.session.SessionStore();
        services.register(net.fabledrealms.fr.session.SessionStore.class, sessionStore);

        var characterRepo = services.get(net.fabledrealms.fr.persistence.repo.CharacterRepository.class);
        var snapshotRepo = services.get(net.fabledrealms.fr.persistence.repo.CharacterSnapshotRepository.class);


        var accountService = new net.fabledrealms.fr.core.AccountService(characterRepo);
        services.register(net.fabledrealms.fr.core.AccountService.class, accountService);

        var characterService = new net.fabledrealms.fr.core.CharacterService(characterRepo, snapshotRepo, 60);
        services.register(net.fabledrealms.fr.core.CharacterService.class, characterService);

        // Register lifecycle
        var lifecycle = new net.fabledrealms.fr.lifecycle.PlayerLifecycleModule(
                getLogger(),
                sessionStore,
                accountService,
                characterService
        );
        services.register(net.fabledrealms.fr.lifecycle.PlayerLifecycleModule.class, lifecycle);

        lifecycle.register(getEventRegistry());

        getCommandRegistry().registerCommand(new net.fabledrealms.fr.command.CharsCommand(services));
        getCommandRegistry().registerCommand(new net.fabledrealms.fr.command.CharCreateCommand(services));
        getCommandRegistry().registerCommand(new net.fabledrealms.fr.command.CharSelectCommand(services));



    }

    @Override
    public void shutdown() {
        if (persistence != null) persistence.close();
        if (services.has(net.fabledrealms.fr.lifecycle.PlayerLifecycleModule.class)) {
            services.get(net.fabledrealms.fr.lifecycle.PlayerLifecycleModule.class).close();
        }
        if (persistence != null) persistence.close();

    }
}
