package net.fabledrealms.fr.core;

import com.fasterxml.jackson.databind.node.ObjectNode;
import net.fabledrealms.fr.persistence.model.CharacterSnapshot;
import net.fabledrealms.fr.persistence.repo.CharacterRepository;
import net.fabledrealms.fr.persistence.repo.CharacterSnapshotRepository;
import net.fabledrealms.fr.session.CharacterSummary;

import javax.annotation.Nonnull;
import java.sql.SQLException;
import java.util.*;

public final class CharacterService {

    private final CharacterRepository characterRepo;
    private final CharacterSnapshotRepository snapshotRepo;
    private final int maxCharactersPerAccount;

    public CharacterService(
            @Nonnull CharacterRepository characterRepo,
            @Nonnull CharacterSnapshotRepository snapshotRepo,
            int maxCharactersPerAccount
    ) {
        this.characterRepo = Objects.requireNonNull(characterRepo, "characterRepo");
        this.snapshotRepo = Objects.requireNonNull(snapshotRepo, "snapshotRepo");
        this.maxCharactersPerAccount = maxCharactersPerAccount;
    }

    public void touchAccount(@Nonnull UUID accountId) throws SQLException {
        characterRepo.ensureAccountExists(accountId);
    }

    @Nonnull
    public List<CharacterSummary> listSummaries(@Nonnull UUID accountId) throws SQLException {
        var rows = characterRepo.listByAccount(accountId);
        List<CharacterSummary> out = new ArrayList<>(rows.size());
        for (var r : rows) {
            out.add(toSummary(r));
        }
        return out;
    }

    @Nonnull
    public UUID create(@Nonnull UUID accountId, @Nonnull String name, @Nonnull String archetypeId) throws SQLException {
        Objects.requireNonNull(accountId, "accountId");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(archetypeId, "archetypeId");

        name = name.trim();
        archetypeId = archetypeId.trim().toLowerCase();

        if (name.isEmpty()) throw new IllegalArgumentException("name cannot be empty");
        if (archetypeId.isEmpty()) throw new IllegalArgumentException("archetypeId cannot be empty");

        touchAccount(accountId);

        int current = characterRepo.countByAccount(accountId);
        if (current >= maxCharactersPerAccount) {
            throw new IllegalStateException("Max characters reached (" + maxCharactersPerAccount + ")");
        }

        return characterRepo.createCharacter(accountId, name, archetypeId);
    }

    @Nonnull
    public Optional<CharacterSnapshot> loadSnapshot(@Nonnull UUID characterId) throws SQLException {
        return snapshotRepo.load(characterId);
    }

    @Nonnull
    public CharacterSnapshot saveSnapshot(@Nonnull UUID characterId, int schemaVersion, @Nonnull ObjectNode data) throws SQLException {
        return snapshotRepo.upsert(characterId, schemaVersion, data);
    }

    private static CharacterSummary toSummary(CharacterRepository.CharacterRow r) {
        // Choose ONE of these depending on your CharacterSummary constructor:

        // Option A: CharacterSummary includes accountId (your current code)
        return new CharacterSummary(
                r.characterId(),
                r.accountId(),
                r.name(),
                r.archetypeId(),
                r.createdAt(),
                r.lastSeenAt()
        );

    }

    public CharacterSummary requireBySlot(List<CharacterSummary> roster, int slot) {
        if (slot < 0 || slot >= roster.size()) {
            throw new IllegalArgumentException("Invalid slot " + slot + " (0-" + Math.max(0, roster.size() - 1) + ")");
        }
        return roster.get(slot);
    }


}
