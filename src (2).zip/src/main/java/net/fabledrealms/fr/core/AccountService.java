package net.fabledrealms.fr.core;

import net.fabledrealms.fr.persistence.repo.CharacterRepository;

import java.sql.SQLException;
import java.util.Objects;
import java.util.UUID;

public final class AccountService {

    private final CharacterRepository characterRepo;

    public AccountService(CharacterRepository characterRepo) {
        this.characterRepo = Objects.requireNonNull(characterRepo, "characterRepo");
    }

    public void ensureAccount(UUID accountId) throws SQLException {
        characterRepo.ensureAccountExists(accountId);
    }
}
