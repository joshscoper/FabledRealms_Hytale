package net.fabledrealms.fr.core;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

public final class Services {

    private final Map<Class<?>, Object> services = new ConcurrentHashMap<>();

    public <T> void register(@Nonnull Class<T> type, @Nonnull T instance) {
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(instance, "instance");
        Object prev = services.putIfAbsent(type, instance);
        if (prev != null) {
            throw new IllegalStateException("Service already registered: " + type.getName());
        }
    }

    @Nonnull
    public <T> T get(@Nonnull Class<T> type) {
        Objects.requireNonNull(type, "type");
        Object obj = services.get(type);
        if (obj == null) {
            throw new IllegalStateException("Missing service: " + type.getName());
        }
        return type.cast(obj);
    }

    public boolean has(@Nonnull Class<?> type) {
        return services.containsKey(type);
    }
}
