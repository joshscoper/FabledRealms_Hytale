package net.fabledrealms.fr.core.snapshot;

import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.UUID;

public final class DefaultSnapshots {

    private DefaultSnapshots() {}

    public static final int SCHEMA_VERSION = 1;

    public static ObjectNode newCharacter(UUID characterId, UUID accountId, String name, String archetypeId) {
        ObjectNode root = JsonNodeFactory.instance.objectNode();

        ObjectNode meta = root.putObject("meta");
        meta.put("schemaVersion", SCHEMA_VERSION);
        meta.put("characterId", characterId.toString());
        meta.put("accountId", accountId.toString());
        meta.put("createdAt", OffsetDateTime.now(ZoneOffset.UTC).toString());
        meta.put("updatedAt", OffsetDateTime.now(ZoneOffset.UTC).toString());

        ObjectNode identity = root.putObject("identity");
        identity.put("name", name);
        identity.put("archetypeId", archetypeId);

        // Minimal progression scaffold
        ObjectNode progression = root.putObject("progression");
        progression.put("level", 1);
        progression.put("xp", 0);

        // Attributes (your current spec)
        ObjectNode attrs = root.putObject("attributes");
        attrs.put("str", 1);
        attrs.put("dex", 1);
        attrs.put("int", 1);
        attrs.put("con", 1);

        // Economy scaffold (ledger is authoritative; this is a cached view)
        ObjectNode economy = root.putObject("economy");
        economy.put("gold", 0);

        return root;
    }
}
