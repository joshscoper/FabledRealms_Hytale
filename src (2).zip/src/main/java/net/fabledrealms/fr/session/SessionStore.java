package net.fabledrealms.fr.session;

import com.hypixel.hytale.server.core.universe.PlayerRef;

import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SessionStore {

    private final ConcurrentHashMap<UUID, PlayerSession> sessions = new ConcurrentHashMap<>();

    private static UUID key(PlayerRef ref) {
        return ref.getUuid();
    }

    public PlayerSession put(PlayerSession session) {
        sessions.put(session.accountId(), session); // accountId == playerRef.getUuid() per your identity rule
        return session;
    }

    public Optional<PlayerSession> get(PlayerRef ref) {
        return Optional.ofNullable(sessions.get(key(ref)));
    }

    public Optional<PlayerSession> get(UUID accountId) {
        return Optional.ofNullable(sessions.get(accountId));
    }

    public void remove(PlayerRef ref) {
        sessions.remove(key(ref));
    }

    public void remove(UUID accountId) {
        sessions.remove(accountId);
    }

    public void clear() {
        sessions.clear();
    }
}
