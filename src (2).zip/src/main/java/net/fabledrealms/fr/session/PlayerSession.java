package net.fabledrealms.fr.session;

import com.hypixel.hytale.server.core.universe.PlayerRef;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class PlayerSession {

    public enum State {
        BOOTSTRAPPING,
        READY,
        IN_WORLD
    }

    private final PlayerRef playerRef;
    private final UUID sessionId;
    private final UUID accountId;
    private volatile State state;
    private volatile java.util.UUID selectedCharacterId;


    private volatile List<CharacterSummary> roster;
    private final long createdAtMs;

    public PlayerSession(PlayerRef playerRef, UUID accountId) {
        this.playerRef = playerRef;
        this.accountId = accountId;
        this.sessionId = UUID.randomUUID();
        this.state = State.BOOTSTRAPPING;
        this.roster = List.of();
        this.createdAtMs = Instant.now().toEpochMilli();
    }

    public PlayerRef playerRef() { return playerRef; }
    public UUID sessionId() { return sessionId; }
    public UUID accountId() { return accountId; }
    public long createdAtMs() { return createdAtMs; }

    public State state() { return state; }
    public void state(State state) { this.state = state; }

    public List<CharacterSummary> roster() { return roster; }
    public void roster(List<CharacterSummary> roster) { this.roster = roster; }

    public java.util.UUID selectedCharacterId() { return selectedCharacterId; }
    public void selectedCharacterId(java.util.UUID id) { this.selectedCharacterId = id; }
}
