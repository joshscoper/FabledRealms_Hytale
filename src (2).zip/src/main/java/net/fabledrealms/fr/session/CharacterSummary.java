package net.fabledrealms.fr.session;

import java.time.OffsetDateTime;
import java.util.UUID;

public record CharacterSummary(
        UUID characterId,
        UUID accountId,
        String name,
        String archetypeId,
        OffsetDateTime createdAt,
        OffsetDateTime lastSeenAt
) {}
