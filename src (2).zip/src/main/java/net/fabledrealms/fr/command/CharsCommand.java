package net.fabledrealms.fr.command;

import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.command.system.AbstractCommand;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import net.fabledrealms.fr.core.Services;
import net.fabledrealms.fr.session.PlayerSession;
import net.fabledrealms.fr.session.SessionStore;

import javax.annotation.Nonnull;
import java.util.concurrent.CompletableFuture;

public final class CharsCommand extends AbstractCommand {

    private final Services services;

    public CharsCommand(Services services) {
        super("chars", "Show your character roster (temporary)");
        this.services = services;
        setAllowsExtraArguments(true);
    }

    @Override
    protected CompletableFuture<Void> execute(@Nonnull CommandContext ctx) {
        if (!ctx.isPlayer()) {
            ctx.sendMessage(Message.raw("Player-only command."));
            return CompletableFuture.completedFuture(null);
        }

        Player player = ctx.senderAs(Player.class);
        PlayerRef ref = player.getPlayerRef();

        SessionStore store = services.get(SessionStore.class);
        PlayerSession session = store.get(ref).orElse(null);

        if (session == null) {
            ctx.sendMessage(Message.raw("No session found (still bootstrapping?)."));
            return CompletableFuture.completedFuture(null);
        }

        ctx.sendMessage(Message.raw(
                "state=" + session.state() +
                        " roster=" + session.roster().size() +
                        " selected=" + session.selectedCharacterId()
        ));

        int i = 0;
        for (var ch : session.roster()) {
            ctx.sendMessage(Message.raw("[" + i + "] " + ch.name() + " (" + ch.archetypeId() + ")"));
            if (++i >= 15) break;
        }

        if (session.roster().isEmpty()) {
            ctx.sendMessage(Message.raw("No characters yet. Use /charcreate <name> <archetypeId>"));
        }

        return CompletableFuture.completedFuture(null);
    }
}
