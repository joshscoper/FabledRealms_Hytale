package net.fabledrealms.fr.command;

import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.command.system.AbstractCommand;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import net.fabledrealms.fr.core.CharacterService;
import net.fabledrealms.fr.core.Services;
import net.fabledrealms.fr.session.PlayerSession;
import net.fabledrealms.fr.session.SessionStore;

import javax.annotation.Nonnull;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class CharCreateCommand extends AbstractCommand {

    private final Services services;

    public CharCreateCommand(Services services) {
        super("charcreate", "Create a character (temporary)");
        this.services = services;
        setAllowsExtraArguments(true);
    }

    @Override
    protected CompletableFuture<Void> execute(@Nonnull CommandContext ctx) {
        if (!ctx.isPlayer()) {
            ctx.sendMessage(Message.raw("Player-only command."));
            return CompletableFuture.completedFuture(null);
        }

        String input = ctx.getInputString().trim();
        String[] parts = input.split("\\s+");

        if (parts.length < 3) {
            ctx.sendMessage(Message.raw("Usage: /charcreate <name> <archetypeId>"));
            return CompletableFuture.completedFuture(null);
        }

        String name = parts[1];
        String archetypeId = parts[2];

        Player player = ctx.senderAs(Player.class);
        PlayerRef ref = player.getPlayerRef();

        SessionStore store = services.get(SessionStore.class);
        CharacterService characterService = services.get(CharacterService.class);

        PlayerSession session = store.get(ref).orElse(null);
        if (session == null) {
            ctx.sendMessage(Message.raw("No session found (try again shortly)."));
            return CompletableFuture.completedFuture(null);
        }

        return CompletableFuture.runAsync(() -> {
            try {
                UUID id = characterService.create(session.accountId(), name, archetypeId);
                session.roster(characterService.listSummaries(session.accountId()));
                ctx.sendMessage(Message.raw("Created: " + name + " id=" + id));
            } catch (Exception e) {
                ctx.sendMessage(Message.raw("Create failed: " + e.getMessage()));
            }
        });
    }
}
