package net.fabledrealms.fr.command;

import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.command.system.AbstractCommand;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import net.fabledrealms.fr.core.Services;
import net.fabledrealms.fr.session.PlayerSession;
import net.fabledrealms.fr.session.SessionStore;

import javax.annotation.Nonnull;
import java.util.concurrent.CompletableFuture;

public final class CharSelectCommand extends AbstractCommand {

    private final Services services;

    public CharSelectCommand(Services services) {
        super("charselect", "Select a character slot (temporary)");
        this.services = services;
        setAllowsExtraArguments(true);
    }

    @Override
    protected CompletableFuture<Void> execute(@Nonnull CommandContext ctx) {
        if (!ctx.isPlayer()) {
            ctx.sendMessage(Message.raw("Player-only command."));
            return CompletableFuture.completedFuture(null);
        }

        String input = ctx.getInputString().trim();
        String[] parts = input.split("\\s+");

        if (parts.length < 2) {
            ctx.sendMessage(Message.raw("Usage: /charselect <slotIndex>"));
            return CompletableFuture.completedFuture(null);
        }

        int slot;
        try {
            slot = Integer.parseInt(parts[1]);
        } catch (NumberFormatException e) {
            ctx.sendMessage(Message.raw("slotIndex must be a number."));
            return CompletableFuture.completedFuture(null);
        }

        Player player = ctx.senderAs(Player.class);
        PlayerRef ref = player.getPlayerRef();

        SessionStore store = services.get(SessionStore.class);
        PlayerSession session = store.get(ref).orElse(null);

        if (session == null) {
            ctx.sendMessage(Message.raw("No session found."));
            return CompletableFuture.completedFuture(null);
        }

        if (slot < 0 || slot >= session.roster().size()) {
            ctx.sendMessage(Message.raw("Invalid slot. You have " + session.roster().size() + " characters."));
            return CompletableFuture.completedFuture(null);
        }

        var chosen = session.roster().get(slot);
        session.selectedCharacterId(chosen.characterId());

        var cs = services.get(net.fabledrealms.fr.core.CharacterService.class);

        try {
            var existing = cs.loadSnapshot(chosen.characterId());
            if (existing.isEmpty()) {
                var data = net.fabledrealms.fr.core.snapshot.DefaultSnapshots.newCharacter(
                        chosen.characterId(),
                        session.accountId(),
                        chosen.name(),
                        chosen.archetypeId()
                );
                cs.saveSnapshot(chosen.characterId(), net.fabledrealms.fr.core.snapshot.DefaultSnapshots.SCHEMA_VERSION, data);
            }
        } catch (Exception e) {
            ctx.sendMessage(Message.raw("Failed loading/creating snapshot: " + e.getMessage()));
            return CompletableFuture.completedFuture(null);
        }

        session.state(PlayerSession.State.IN_WORLD);

        ctx.sendMessage(Message.raw(
                "Selected [" + slot + "]: " + chosen.name() + " (" + chosen.archetypeId() + ") - entering world"
        ));

        return CompletableFuture.completedFuture(null);
    }
}
