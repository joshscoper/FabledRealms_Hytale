package net.fabledrealms.fr.identity;

import com.hypixel.hytale.server.core.universe.PlayerRef;

import java.util.UUID;

public final class AccountIdentity {

    private AccountIdentity() {}

    public static UUID accountIdFrom(PlayerRef ref) {
        return ref.getUuid();
    }
}
