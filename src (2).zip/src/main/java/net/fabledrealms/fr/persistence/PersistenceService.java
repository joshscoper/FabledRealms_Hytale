package net.fabledrealms.fr.persistence;

import com.hypixel.hytale.logger.HytaleLogger;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.flywaydb.core.Flyway;

import javax.annotation.Nonnull;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Objects;
import java.util.logging.Level;

public final class PersistenceService implements AutoCloseable {

    private final HytaleLogger logger;
    private final DbConfig config;
    private HikariDataSource dataSource;

    public PersistenceService(@Nonnull HytaleLogger logger, @Nonnull DbConfig config) {
        this.logger = Objects.requireNonNull(logger, "logger");
        this.config = Objects.requireNonNull(config, "config");
    }

    public void start() {
        if (dataSource != null) return;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("MySQL driver missing (mysql-connector-j not shaded).", e);
        }

        HikariConfig hc = new HikariConfig();
        hc.setJdbcUrl(config.jdbcUrl());
        hc.setUsername(config.username());
        hc.setPassword(config.password());
        hc.setDriverClassName("com.mysql.cj.jdbc.Driver");

        hc.setMaximumPoolSize(config.maxPoolSize());
        hc.setMinimumIdle(1);
        hc.setConnectionTimeout(10_000);
        hc.setValidationTimeout(5_000);
        hc.setIdleTimeout(60_000);
        hc.setMaxLifetime(600_000);
        hc.setConnectionTestQuery("SELECT 1");
        hc.setInitializationFailTimeout(10_000);

        dataSource = new HikariDataSource(hc);

        runMigrations();

        try (Connection c = dataSource.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT 1")) {
            ps.execute();
        } catch (Exception e) {
            throw new IllegalStateException("Database health check failed", e);
        }

        logger.at(Level.INFO).log("[FR] PersistenceService started successfully.");
    }

    private void runMigrations() {
        ClassLoader pluginCl = getClass().getClassLoader();
        Thread t = Thread.currentThread();
        ClassLoader old = t.getContextClassLoader();

        try {
            t.setContextClassLoader(pluginCl);

            Flyway flyway = Flyway.configure()
                    .dataSource(dataSource)
                    .locations("classpath:db/migration")
                    .baselineOnMigrate(true)
                    .load();

            try {
                var result = flyway.migrate();
                logger.at(Level.INFO).log("[FR] Flyway migrations applied: " + result.migrationsExecuted);
            } catch (org.flywaydb.core.api.exception.FlywayValidateException validateEx) {
                logger.at(Level.WARNING).log("[FR] Flyway validation failed. Running repair(), then retrying migrate().", validateEx);

                // Marks failed migrations as deleted/removed in schema history and realigns checksums.
                flyway.repair();

                var result = flyway.migrate();
                logger.at(Level.INFO).log("[FR] Flyway migrations applied after repair: " + result.migrationsExecuted);
            }

        } finally {
            t.setContextClassLoader(old);
        }
    }


    @Nonnull
    public DataSource dataSource() {
        if (dataSource == null) throw new IllegalStateException("PersistenceService not started");
        return dataSource;
    }

    @Override
    public void close() {
        if (dataSource != null) {
            dataSource.close();
            dataSource = null;
        }
    }
}
