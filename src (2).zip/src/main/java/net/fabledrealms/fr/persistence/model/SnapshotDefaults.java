package net.fabledrealms.fr.persistence.model;

import com.fasterxml.jackson.databind.node.ObjectNode;
import net.fabledrealms.fr.persistence.json.Json;

import java.time.OffsetDateTime;
import java.util.UUID;

public final class SnapshotDefaults {
    private SnapshotDefaults() {}

    public static final int CURRENT_SCHEMA_VERSION = 1;

    public static ObjectNode newV1(UUID characterId, String name, String classId) {
        ObjectNode root = Json.mapper().createObjectNode();

        ObjectNode meta = root.putObject("meta");
        meta.put("schemaVersion", CURRENT_SCHEMA_VERSION);
        meta.put("revision", 0);
        meta.put("createdAt", OffsetDateTime.now().toString());
        meta.put("updatedAt", OffsetDateTime.now().toString());
        meta.put("serverId", "single");

        ObjectNode identity = root.putObject("identity");
        identity.put("characterId", characterId.toString());
        identity.put("name", name);
        identity.put("classId", classId);

        ObjectNode prog = root.putObject("progression");
        prog.put("level", 1);
        prog.put("xp", 0);
        prog.put("unspentPoints", 0);

        ObjectNode attrs = root.putObject("attributes");
        ObjectNode base = attrs.putObject("base");
        base.put("attr.str", 0);
        base.put("attr.dex", 0);
        base.put("attr.int", 0);
        base.put("attr.con", 0);
        ObjectNode bonus = attrs.putObject("bonus");
        bonus.put("attr.str", 0);
        bonus.put("attr.dex", 0);
        bonus.put("attr.int", 0);
        bonus.put("attr.con", 0);

        root.putObject("skills");
        ObjectNode wallet = root.putObject("wallet");
        wallet.put("currency.gold", 0);
        wallet.put("currency.arcane_token", 0);

        root.putObject("quests").putObject("active");
        root.with("quests").putObject("completed");

        ObjectNode ui = root.putObject("ui");
        ui.put("hudProfile", "ui.hud.default");
        ui.put("scoreboardMode", "DEFAULT");
        ui.putNull("trackedQuestId");

        ObjectNode flags = root.putObject("flags");
        flags.put("starterKitGranted", false);
        flags.put("tutorialSkipped", false);

        root.putObject("ext").putObject("custom");

        return root;
    }
}
