package net.fabledrealms.fr.persistence;

import net.fabledrealms.fr.persistence.model.SnapshotDefaults;
import net.fabledrealms.fr.persistence.repo.CharacterRepository;
import net.fabledrealms.fr.persistence.repo.CharacterSnapshotRepository;

import java.util.UUID;
import java.util.logging.Logger;

public final class PersistenceSelfTest {

    private final Logger logger;
    private final CharacterRepository characters;
    private final CharacterSnapshotRepository snapshots;

    public PersistenceSelfTest(Logger logger, CharacterRepository characters, CharacterSnapshotRepository snapshots) {
        this.logger = logger;
        this.characters = characters;
        this.snapshots = snapshots;
    }

    public void run() throws Exception {
        UUID accountId = UUID.randomUUID();

        characters.ensureAccountExists(accountId);

        UUID characterId = characters.createCharacter(accountId, "DBTest_" + System.currentTimeMillis(), "class.warrior");

        var data = SnapshotDefaults.newV1(characterId, "DBTest", "class.warrior");
        var upserted = snapshots.upsert(characterId, SnapshotDefaults.CURRENT_SCHEMA_VERSION, data);

        var loaded = snapshots.load(characterId).orElseThrow();

        logger.info("[FR] Persistence self-test OK: characterId=" + characterId
                + " revision=" + upserted.revision()
                + " loadedRevision=" + loaded.revision());
    }
}
