package net.fabledrealms.fr.persistence.repo;

import javax.sql.DataSource;
import java.sql.*;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;

public final class CharacterRepository {

    private final DataSource ds;

    public CharacterRepository(DataSource ds) {
        this.ds = Objects.requireNonNull(ds, "ds");
    }

    public void ensureAccountExists(UUID accountId) throws SQLException {
        String sql = """
            INSERT INTO account (account_id, last_login_at, flags)
            VALUES (?, CURRENT_TIMESTAMP, JSON_OBJECT())
            ON DUPLICATE KEY UPDATE last_login_at = CURRENT_TIMESTAMP
        """;
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, accountId.toString());
            ps.executeUpdate();
        }
    }

    public UUID createCharacter(UUID accountId, String name, String archetypeId) throws SQLException {
        UUID characterId = UUID.randomUUID();
        String sql = """
            INSERT INTO characters (character_id, account_id, name, archetype_id)
            VALUES (?, ?, ?, ?)
        """;
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, characterId.toString());
            ps.setString(2, accountId.toString());
            ps.setString(3, name);
            ps.setString(4, archetypeId);
            ps.executeUpdate();
        }
        return characterId;
    }

    public record CharacterRow(
            UUID characterId,
            UUID accountId,
            String name,
            String archetypeId,
            OffsetDateTime createdAt,
            OffsetDateTime lastSeenAt
    ) {}

    public int countByAccount(UUID accountId) throws SQLException {
        String sql = """
        SELECT COUNT(*) AS c
        FROM characters
        WHERE account_id = ?
    """;
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, accountId.toString());
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt("c");
            }
        }
    }


    public List<CharacterRow> listByAccount(UUID accountId) throws SQLException {
        String sql = """
            SELECT character_id, account_id, name, archetype_id, created_at, last_seen_at
            FROM characters
            WHERE account_id = ?
            ORDER BY created_at ASC
        """;
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, accountId.toString());

            try (ResultSet rs = ps.executeQuery()) {
                List<CharacterRow> out = new ArrayList<>();
                while (rs.next()) {
                    out.add(new CharacterRow(
                            UUID.fromString(rs.getString("character_id")),
                            UUID.fromString(rs.getString("account_id")),
                            rs.getString("name"),
                            rs.getString("archetype_id"),
                            toOffsetDateTimeUtc(rs.getTimestamp("created_at")),
                            toOffsetDateTimeUtc(rs.getTimestamp("last_seen_at"))
                    ));
                }
                return out;
            }
        }
    }

    private static OffsetDateTime toOffsetDateTimeUtc(Timestamp ts) {
        if (ts == null) return null;
        return ts.toInstant().atOffset(ZoneOffset.UTC);
    }
}
