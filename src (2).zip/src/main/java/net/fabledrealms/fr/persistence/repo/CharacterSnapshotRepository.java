package net.fabledrealms.fr.persistence.repo;

import com.fasterxml.jackson.databind.node.ObjectNode;
import net.fabledrealms.fr.persistence.json.Json;
import net.fabledrealms.fr.persistence.model.CharacterSnapshot;

import javax.sql.DataSource;
import java.sql.*;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public final class CharacterSnapshotRepository {

    private final DataSource ds;

    public CharacterSnapshotRepository(DataSource ds) {
        this.ds = Objects.requireNonNull(ds, "ds");
    }

    public Optional<CharacterSnapshot> load(UUID characterId) throws SQLException {
        String sql = """
            SELECT character_id, revision, schema_version, data, updated_at
            FROM character_snapshot
            WHERE character_id = ?
        """;
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, characterId.toString());

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return Optional.empty();

                ObjectNode node = parseObjectNode(rs.getString("data"), "character " + characterId);

                return Optional.of(new CharacterSnapshot(
                        UUID.fromString(rs.getString("character_id")),
                        rs.getLong("revision"),
                        rs.getInt("schema_version"),
                        node,
                        toOffsetDateTimeUtc(rs.getTimestamp("updated_at"))
                ));
            }
        }
    }

    /**
     * Upserts the snapshot and increments revision atomically:
     * - if exists: revision = revision + 1
     * - if not: revision = 1
     *
     * MySQL note: INSERT...ON DUPLICATE KEY does not return a row, so we do:
     * 1) executeUpdate()
     * 2) SELECT row back
     */
    public CharacterSnapshot upsert(UUID characterId, int schemaVersion, ObjectNode data) throws SQLException {
        Objects.requireNonNull(data, "data");

        // Ensure meta mirrors columns (helpful for debugging)
        ObjectNode meta = data.with("meta");
        meta.put("schemaVersion", schemaVersion);
        meta.put("updatedAt", OffsetDateTime.now(ZoneOffset.UTC).toString());

        String upsertSql = """
            INSERT INTO character_snapshot (character_id, revision, schema_version, data, updated_at)
            VALUES (?, 1, ?, ?, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
              revision = revision + 1,
              schema_version = VALUES(schema_version),
              data = VALUES(data),
              updated_at = CURRENT_TIMESTAMP
        """;

        String selectSql = """
            SELECT character_id, revision, schema_version, data, updated_at
            FROM character_snapshot
            WHERE character_id = ?
        """;

        try (Connection c = ds.getConnection()) {
            // Optional but recommended: keep it consistent under concurrency
            boolean oldAutoCommit = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                try (PreparedStatement ps = c.prepareStatement(upsertSql)) {
                    ps.setString(1, characterId.toString());
                    ps.setInt(2, schemaVersion);
                    ps.setString(3, data.toString());
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = c.prepareStatement(selectSql)) {
                    ps.setString(1, characterId.toString());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new SQLException("Snapshot upsert succeeded but row not found for character " + characterId);
                        }

                        ObjectNode node = parseObjectNode(rs.getString("data"), "character " + characterId);

                        CharacterSnapshot snap = new CharacterSnapshot(
                                UUID.fromString(rs.getString("character_id")),
                                rs.getLong("revision"),
                                rs.getInt("schema_version"),
                                node,
                                toOffsetDateTimeUtc(rs.getTimestamp("updated_at"))
                        );

                        c.commit();
                        return snap;
                    }
                }
            } catch (SQLException e) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw e;
            } finally {
                try { c.setAutoCommit(oldAutoCommit); } catch (SQLException ignored) {}
            }
        }
    }

    private static ObjectNode parseObjectNode(String json, String context) throws SQLException {
        try {
            return (ObjectNode) Json.mapper().readTree(json);
        } catch (Exception e) {
            throw new SQLException("Failed to parse snapshot JSON for " + context, e);
        }
    }

    private static OffsetDateTime toOffsetDateTimeUtc(Timestamp ts) {
        if (ts == null) return null;
        return ts.toInstant().atOffset(ZoneOffset.UTC);
    }
}
