package net.fabledrealms.fr.persistence;

public final class DbConfig {

    private static final String JDBC_URL =
            "jdbc:mysql://u47316102_2mlGHjZBMR:1njaRiFX0sWx6Rwgu98kgVuq@gamesdal114.bisecthosting.com:3306/s47316102_fabledrealms";

    private static final String USERNAME =
            "u47316102_2mlGHjZBMR";

    private static final String PASSWORD =
            "1njaRiFX0sWx6Rwgu98kgVuq";

    private static final int MAX_POOL_SIZE = 8;

    private DbConfig() {}

    public static DbConfig loadOrCreate() {
        return new DbConfig();
    }

    public String jdbcUrl() {
        return JDBC_URL;
    }

    public String username() {
        return USERNAME;
    }

    public String password() {
        return PASSWORD;
    }

    public int maxPoolSize() {
        return MAX_POOL_SIZE;
    }
}
