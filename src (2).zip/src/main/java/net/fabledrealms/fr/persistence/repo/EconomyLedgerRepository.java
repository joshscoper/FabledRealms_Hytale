package net.fabledrealms.fr.persistence.repo;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Objects;
import java.util.UUID;

public final class EconomyLedgerRepository {

    private final DataSource ds;

    public EconomyLedgerRepository(DataSource ds) {
        this.ds = Objects.requireNonNull(ds, "ds");
    }

    /**
     * Appends a ledger row. Idempotent by txId:
     * - returns true if inserted
     * - returns false if txId already existed (duplicate)
     */
    public boolean append(UUID txId,
                          UUID characterId,
                          String currencyId,
                          long delta,
                          String reason,
                          String metaJson) throws SQLException {

        String sql = """
            INSERT INTO economy_ledger
              (tx_id, character_id, currency_id, delta, reason, meta, created_at)
            VALUES
              (?, ?, ?, ?, ?, COALESCE(CAST(? AS JSON), JSON_OBJECT()), CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
              tx_id = tx_id
        """;

        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, txId.toString());
            ps.setString(2, characterId.toString());
            ps.setString(3, currencyId);
            ps.setLong(4, delta);
            ps.setString(5, reason);
            ps.setString(6, metaJson);

            int updated = ps.executeUpdate();

            // MySQL returns:
            // - 1 for insert
            // - 2 for "update" in some cases (not here because tx_id=tx_id is no-op)
            // - 0 for no-op (but depends on driver settings)
            //
            // With tx_id = tx_id, duplicates commonly return 0.
            return updated == 1;
        }
    }
}
