package net.fabledrealms.fr.persistence.model;

import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.OffsetDateTime;
import java.util.UUID;

public record CharacterSnapshot(
        UUID characterId,
        long revision,
        int schemaVersion,
        ObjectNode data,
        OffsetDateTime updatedAt
) {}
