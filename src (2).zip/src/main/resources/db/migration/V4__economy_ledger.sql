CREATE TABLE IF NOT EXISTS economy_ledger (
                                              tx_id CHAR(36) PRIMARY KEY,
                                              character_id CHAR(36) NOT NULL,
                                              currency_id VARCHAR(64) NOT NULL,
                                              delta BIGINT NOT NULL,
                                              reason VARCHAR(255) NOT NULL,
                                              meta JSON NOT NULL,
                                              created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                              CONSTRAINT fk_ledger_character
                                                  FOREIGN KEY (character_id) REFERENCES characters(character_id)
                                                      ON DELETE CASCADE
) ENGINE=InnoDB;

-- idx_economy_ledger_character_time
SET @idx := (
    SELECT COUNT(1)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'economy_ledger'
    AND INDEX_NAME = 'idx_economy_ledger_character_time'
    );
SET @sql := IF(@idx = 0,
    'ALTER TABLE economy_ledger ADD INDEX idx_economy_ledger_character_time (character_id, created_at)',
    'SELECT 1'
    );
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- idx_economy_ledger_currency
SET @idx := (
    SELECT COUNT(1)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'economy_ledger'
    AND INDEX_NAME = 'idx_economy_ledger_currency'
    );
SET @sql := IF(@idx = 0,
    'ALTER TABLE economy_ledger ADD INDEX idx_economy_ledger_currency (currency_id)',
    'SELECT 1'
    );
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
