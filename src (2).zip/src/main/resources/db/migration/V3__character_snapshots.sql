CREATE TABLE IF NOT EXISTS character_snapshot (
                                                  character_id CHAR(36) PRIMARY KEY,
                                                  revision BIGINT NOT NULL,
                                                  schema_version INT NOT NULL,
                                                  data JSON NOT NULL,
                                                  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                                  CONSTRAINT fk_snapshot_character
                                                      FOREIGN KEY (character_id) REFERENCES characters(character_id)
                                                          ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_character_snapshot_updated_at
    ON character_snapshot(updated_at);
