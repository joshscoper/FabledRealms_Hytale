CREATE TABLE IF NOT EXISTS characters (
                                          character_id CHAR(36) PRIMARY KEY,
                                          account_id CHAR(36) NOT NULL,
                                          name VARCHAR(64) NOT NULL,
                                          archetype_id VARCHAR(64) NOT NULL,
                                          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                          last_seen_at TIMESTAMP NULL DEFAULT NULL,
                                          CONSTRAINT fk_characters_account
                                              FOREIGN KEY (account_id) REFERENCES account(account_id)
                                                  ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_characters_account_id
    ON characters(account_id);

CREATE UNIQUE INDEX uq_characters_account_name
    ON characters(account_id, name);
