CREATE TABLE IF NOT EXISTS account (
                                       account_id CHAR(36) PRIMARY KEY,
                                       created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                       last_login_at TIMESTAMP NULL DEFAULT NULL,
                                       flags JSON NOT NULL
) ENGINE=InnoDB;

CREATE INDEX idx_account_last_login_at
    ON account(last_login_at);
