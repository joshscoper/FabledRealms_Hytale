package net.fabledrealms.bootstrap;

import net.fabledrealms.FabledRealmsPlugin;
import net.fabledrealms.config.ConfigManager;
import net.fabledrealms.config.ConfigService;
import net.fabledrealms.service.ServiceRegistry;

public record PluginContext(
        FabledRealmsPlugin plugin,
        ServiceRegistry services,
        ConfigService configFiles,
        ConfigManager configs
) {}
