package net.fabledrealms.bootstrap;

import net.fabledrealms.FabledRealmsPlugin;
import net.fabledrealms.config.ConfigManager;
import net.fabledrealms.config.ConfigService;
import net.fabledrealms.module.ModuleManager;
import net.fabledrealms.module.core.CoreModule;
import net.fabledrealms.service.ServiceRegistry;

public final class Bootstrap {

    private final FabledRealmsPlugin plugin;

    private PluginContext context;
    private ModuleManager modules;

    public Bootstrap(FabledRealmsPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        ServiceRegistry services = new ServiceRegistry();
        ConfigService configFiles = new ConfigService(plugin);
        ConfigManager configs = new ConfigManager(configFiles);

        configs.loadAll();

        this.context = new PluginContext(plugin, services, configFiles, configs);

        this.modules = new ModuleManager(context);
        this.modules.register(new CoreModule());


        this.modules.enableAll();
    }

    public void stop() {
        if (modules != null) modules.disableAll();
    }
}
