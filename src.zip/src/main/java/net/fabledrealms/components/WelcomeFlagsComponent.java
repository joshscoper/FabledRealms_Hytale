package net.fabledrealms.components;

public record WelcomeFlagsComponent(
        boolean starterCrateGranted,
        boolean tutorialCompleted
) {
    public static WelcomeFlagsComponent defaults() {
        return new WelcomeFlagsComponent(false, false);
    }
}
