package net.fabledrealms.components;

public record WalletComponent(
        long gold,
        long arcaneTokens
) {
    public static WalletComponent defaults() {
        return new WalletComponent(0L, 0L);
    }
}
