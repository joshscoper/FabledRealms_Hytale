package net.fabledrealms.module;

import net.fabledrealms.bootstrap.PluginContext;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {

    private final PluginContext ctx;
    private final List<Module> modules = new ArrayList<>();
    private final List<Module> enabled = new ArrayList<>();

    public ModuleManager(PluginContext ctx) {
        this.ctx = ctx;
    }

    public void register(Module module) {
        modules.add(module);
    }

    public void enableAll() {
        for (Module m : modules) {
            m.enable(ctx);
            enabled.add(m);
        }
    }

    public void disableAll() {
        // disable in reverse order
        for (int i = enabled.size() - 1; i >= 0; i--) {
            enabled.get(i).disable();
        }
        enabled.clear();
    }
}
