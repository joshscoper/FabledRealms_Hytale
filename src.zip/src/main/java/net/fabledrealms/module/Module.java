package net.fabledrealms.module;

import net.fabledrealms.bootstrap.PluginContext;

public interface Module {
    String id();
    void enable(PluginContext ctx);
    void disable();
}
