package net.fabledrealms.module.core;

import net.fabledrealms.bootstrap.PluginContext;
import net.fabledrealms.module.Module;

import java.util.logging.Level;

public final class CoreModule implements Module {

    @Override
    public String id() {
        return "core";
    }

    @Override
    public void enable(PluginContext ctx) {

        // TODO: register your world-thread dispatcher once you wire the Hytale scheduling API
        // ctx.services().register(WorldThreadDispatcher.class, new HytaleWorldThreadDispatcher(...));

        ctx.plugin().getLogger().at(Level.INFO).log("Core enabled. env=" + ctx.configs().plugin().environment());
    }

    @Override
    public void disable() {
        // Close/flush anything Core owns (executors, tasks, etc.)
    }
}
