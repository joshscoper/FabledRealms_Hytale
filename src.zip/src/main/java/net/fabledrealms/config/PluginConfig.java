package net.fabledrealms.config;

public record PluginConfig(
        String environment,   // "dev" | "prod"
        boolean debug,
        String locale
) {
    public static PluginConfig defaults() {
        return new PluginConfig("dev", true, "en_US");
    }
}
