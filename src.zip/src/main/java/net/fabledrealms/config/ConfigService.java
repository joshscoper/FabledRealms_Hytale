package net.fabledrealms.config;

import com.hypixel.hytale.server.core.plugin.JavaPlugin;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public final class ConfigService {

    private final JavaPlugin plugin;
    private final Path rootDir;
    private final Path configDir;
    private final Path modulesDir;

    public ConfigService(JavaPlugin plugin) {
        this.plugin = plugin;

        // If the API exposes a data folder accessor, use it.
        // If it doesn't, fall back to a conventional plugins/<PluginName> folder.
        // Adjust this to whatever Hytale exposes in your jar.
        this.rootDir = Paths.get("plugins", plugin.getName());
        this.configDir = rootDir.resolve("config");
        this.modulesDir = configDir.resolve("modules");

        ensureDirs();
    }

    public Path rootDir()     { return rootDir; }
    public Path configDir()   { return configDir; }
    public Path modulesDir()  { return modulesDir; }

    private void ensureDirs() {
        try {
            Files.createDirectories(modulesDir);
        } catch (IOException e) {
            throw new IllegalStateException("Failed to create config directories: " + modulesDir, e);
        }
    }

    /** Read a config file, creating it with defaults if missing. */
    public String readOrCreate(Path path, String defaultContents) {
        try {
            if (Files.notExists(path)) {
                Files.createDirectories(path.getParent());
                Files.writeString(path, defaultContents, StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                return defaultContents;
            }
            return Files.readString(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("Failed to read config: " + path, e);
        }
    }

    /** Write config file (atomic-ish: write temp then move). */
    public void write(Path path, String contents) {
        try {
            Files.createDirectories(path.getParent());
            Path tmp = path.resolveSibling(path.getFileName().toString() + ".tmp");
            Files.writeString(tmp, contents, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            throw new IllegalStateException("Failed to write config: " + path, e);
        }
    }

    public Path pluginConfigPath() {
        return configDir.resolve("plugin.json");
    }

    public Path moduleConfigPath(String moduleId) {
        return modulesDir.resolve(moduleId + ".json");
    }
}
