package net.fabledrealms.config;

import java.nio.file.Path;

public final class ConfigManager {

    private final ConfigService files;
    private PluginConfig pluginConfig;

    public ConfigManager(ConfigService files) {
        this.files = files;
    }

    public void loadAll() {
        this.pluginConfig = loadPluginConfig();
    }

    public PluginConfig plugin() {
        return pluginConfig;
    }

    public PluginConfig loadPluginConfig() {
        Path path = files.pluginConfigPath();
        String json = files.readOrCreate(path, PluginConfigDefaults.json());

        PluginConfig cfg = JsonConfigCodec.fromJson(json, PluginConfig.class);
        if (cfg == null) {
            cfg = PluginConfig.defaults();
            files.write(path, JsonConfigCodec.toJson(cfg));
        }

        this.pluginConfig = cfg;
        return cfg;
    }

    public void savePlugin() {
        files.write(files.pluginConfigPath(), JsonConfigCodec.toJson(pluginConfig));
    }
}
