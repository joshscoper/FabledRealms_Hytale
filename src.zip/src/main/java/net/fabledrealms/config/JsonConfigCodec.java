package net.fabledrealms.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public final class JsonConfigCodec {

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create();

    private JsonConfigCodec() {}

    public static <T> T fromJson(String json, Class<T> type) {
        return GSON.fromJson(json, type);
    }

    public static String toJson(Object obj) {
        return GSON.toJson(obj);
    }
}
