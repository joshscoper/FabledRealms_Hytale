package net.fabledrealms.config;

public final class PluginConfigDefaults {

    private PluginConfigDefaults() {}

    public static String json() {
        return """
        {
          "environment": "dev",
          "debug": true,
          "locale": "en_US"
        }
        """;
    }
}
