package net.fabledrealms.config;

public final class Env {
    private Env() {}

    public static String get(String key, String fallback) {
        String v = System.getenv(key);
        return (v == null || v.isBlank()) ? fallback : v;
    }

    public static int getInt(String key, int fallback) {
        String v = System.getenv(key);
        if (v == null || v.isBlank()) return fallback;
        try { return Integer.parseInt(v.trim()); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    public static boolean getBool(String key, boolean fallback) {
        String v = System.getenv(key);
        if (v == null || v.isBlank()) return fallback;
        return v.trim().equalsIgnoreCase("true") || v.trim().equals("1") || v.trim().equalsIgnoreCase("yes");
    }
}
