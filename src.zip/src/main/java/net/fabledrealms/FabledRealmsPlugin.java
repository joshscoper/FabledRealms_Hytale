package net.fabledrealms;

import com.hypixel.hytale.server.core.plugin.JavaPlugin;
import com.hypixel.hytale.server.core.plugin.JavaPluginInit;
import net.fabledrealms.bootstrap.Bootstrap;

import javax.annotation.Nonnull;

public final class FabledRealmsPlugin extends JavaPlugin {

    private Bootstrap bootstrap;

    public FabledRealmsPlugin(@Nonnull JavaPluginInit init) {
        super(init);
    }

    @Override
    public void start() {
        this.bootstrap = new Bootstrap(this);
        this.bootstrap.start();
    }

    @Override
    public void shutdown() {
        if (this.bootstrap != null) {
            this.bootstrap.stop();
            this.bootstrap = null;
        }
    }
}
