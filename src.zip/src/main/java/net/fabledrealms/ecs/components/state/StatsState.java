package net.fabledrealms.ecs.components.state;

public record StatsState(
        int str,
        int dex,
        int intel,
        int vit
) {}
