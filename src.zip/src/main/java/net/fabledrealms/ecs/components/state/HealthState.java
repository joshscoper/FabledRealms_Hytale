package net.fabledrealms.ecs.components.state;

public record HealthState(
        double currentHp,
        double maxHp
) {}
