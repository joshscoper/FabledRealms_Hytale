package net.fabledrealms.ecs.components.def;

public record CombatDef(
        double baseDamage,
        double attackSpeed,
        double aggroRadius
) {}
