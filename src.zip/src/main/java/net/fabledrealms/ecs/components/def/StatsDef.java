package net.fabledrealms.ecs.components.def;

public record StatsDef(
        int baseStr,
        int baseDex,
        int baseInt,
        int baseVit,
        double hpPerVit
) {}
