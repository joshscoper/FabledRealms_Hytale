package net.fabledrealms.ecs.components.def;

public record DialogueDef(
        String dialogueGraphId
) {}
