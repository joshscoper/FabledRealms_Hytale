package net.fabledrealms.ecs.components.mod;

import java.util.UUID;

public record StatModifier(
        UUID sourceId,
        String sourceTag,     // "buff.food", "zone.cold", "equipment.sword"
        long expiresAtMs,     // 0 = permanent until removed
        int addStr,
        int addDex,
        int addInt,
        int addVit,
        double mulDamage      // example multiplier channel
) {}
