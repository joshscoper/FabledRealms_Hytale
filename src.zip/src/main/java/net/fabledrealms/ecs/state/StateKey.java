package net.fabledrealms.ecs.state;

import java.util.Objects;

public final class StateKey<T> {
    private final String id;
    private final Class<T> type;

    private StateKey(String id, Class<T> type) {
        this.id = Objects.requireNonNull(id);
        this.type = Objects.requireNonNull(type);
    }

    public static <T> StateKey<T> of(String id, Class<T> type) {
        return new StateKey<>(id, type);
    }

    public String id() { return id; }
    public Class<T> type() { return type; }
}
