package net.fabledrealms.ecs.runtime;

import net.fabledrealms.ecs.core.Identity;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class RebuildService {

    private final EntityAssembler assembler;

    // Track live identities (you populate this on spawn/connect)
    private final Set<Identity> live = ConcurrentHashMap.newKeySet();

    public RebuildService(EntityAssembler assembler) {
        this.assembler = assembler;
    }

    public void track(Identity id) {
        live.add(id);
    }

    public void untrack(Identity id) {
        live.remove(id);
    }

    public void rebuildArchetype(String archetypeId, RebuildPolicy policy) {
        for (Identity id : live) {
            if (archetypeId.equals(id.archetypeId())) {
                assembler.rebuild(id, policy);
            }
        }
    }

    public void rebuildEntity(Identity id, RebuildPolicy policy) {
        assembler.rebuild(id, policy);
    }
}
