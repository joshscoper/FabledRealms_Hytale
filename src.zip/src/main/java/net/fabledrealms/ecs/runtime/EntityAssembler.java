package net.fabledrealms.ecs.runtime;

import net.fabledrealms.ecs.core.Identity;

public interface EntityAssembler {

    void assembleInitial(Identity identity);

    void rebuild(Identity identity, RebuildPolicy policy);
}
