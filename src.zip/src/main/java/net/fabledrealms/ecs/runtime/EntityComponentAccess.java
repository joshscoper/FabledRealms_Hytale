package net.fabledrealms.ecs.runtime;

import java.util.Optional;
import java.util.UUID;

public interface EntityComponentAccess {

    <T> Optional<T> get(UUID entityId, Class<T> componentType);

    <T> void set(UUID entityId, Class<T> componentType, T component);

    <T> void remove(UUID entityId, Class<T> componentType);
}
