package net.fabledrealms.ecs.runtime;

import net.fabledrealms.ecs.components.def.CombatDef;
import net.fabledrealms.ecs.components.def.StatsDef;
import net.fabledrealms.ecs.components.state.HealthState;
import net.fabledrealms.ecs.components.state.StatsState;
import net.fabledrealms.ecs.core.Identity;
import net.fabledrealms.ecs.def.DefKey;
import net.fabledrealms.ecs.def.DefMerger;
import net.fabledrealms.ecs.def.DefLayer;
import net.fabledrealms.ecs.def.DefinitionRegistry;

import java.util.Optional;

public final class DefaultEntityAssembler implements EntityAssembler {

    public static final DefKey<StatsDef> DEF_STATS = DefKey.of("stats", StatsDef.class);
    public static final DefKey<CombatDef> DEF_COMBAT = DefKey.of("combat", CombatDef.class);

    private final DefinitionRegistry defs;
    private final EntityComponentAccess ecs;
    private final DefMerger merger;

    public DefaultEntityAssembler(DefinitionRegistry defs, EntityComponentAccess ecs) {
        this.defs = defs;
        this.ecs = ecs;
        this.merger = new DefMerger(java.util.List.of(
                DefLayer.BASE, DefLayer.KIND, DefLayer.ARCHETYPE, DefLayer.ZONE, DefLayer.INSTANCE, DefLayer.TEMP
        ));
    }

    @Override
    public void assembleInitial(Identity id) {
        // Build base runtime state from definitions
        StatsDef statsDef = effectiveStats(id);
        StatsState statsState = new StatsState(statsDef.baseStr(), statsDef.baseDex(), statsDef.baseInt(), statsDef.baseVit());
        ecs.set(id.entityId(), StatsState.class, statsState);

        // Derived: max HP from vit
        double maxHp = computeMaxHp(statsDef, statsState);
        ecs.set(id.entityId(), HealthState.class, new HealthState(maxHp, maxHp));

        // Combat derived values could be stored in CombatState if you want
        // For now, we just ensure CombatDef exists and is accessible for systems.
        CombatDef combatDef = effectiveCombat(id);
        ecs.set(id.entityId(), CombatDef.class, combatDef); // yes, defs can be attached too if you want local caching
    }

    @Override
    public void rebuild(Identity id, RebuildPolicy policy) {
        if (policy == RebuildPolicy.NO_ACTION) return;

        StatsDef statsDef = effectiveStats(id);

        if (policy == RebuildPolicy.RESET_STATE) {
            StatsState statsState = new StatsState(statsDef.baseStr(), statsDef.baseDex(), statsDef.baseInt(), statsDef.baseVit());
            ecs.set(id.entityId(), StatsState.class, statsState);

            double maxHp = computeMaxHp(statsDef, statsState);
            ecs.set(id.entityId(), HealthState.class, new HealthState(maxHp, maxHp));
        } else {
            // DERIVED_ONLY: preserve current HP ratio, update max HP
            StatsState statsState = ecs.get(id.entityId(), StatsState.class)
                    .orElse(new StatsState(statsDef.baseStr(), statsDef.baseDex(), statsDef.baseInt(), statsDef.baseVit()));

            double oldMax = ecs.get(id.entityId(), HealthState.class).map(HealthState::maxHp).orElse(1.0);
            double oldCur = ecs.get(id.entityId(), HealthState.class).map(HealthState::currentHp).orElse(oldMax);
            double ratio = (oldMax <= 0.0001) ? 1.0 : clamp01(oldCur / oldMax);

            double newMax = computeMaxHp(statsDef, statsState);
            double newCur = newMax * ratio;

            ecs.set(id.entityId(), HealthState.class, new HealthState(newCur, newMax));
        }

        // Update cached def if you attach it
        ecs.set(id.entityId(), CombatDef.class, effectiveCombat(id));
    }

    private StatsDef effectiveStats(Identity id) {
        StatsDef fallback = new StatsDef(1, 1, 1, 1, 10.0);

        return merger.merge(layer ->
                        defs.get(layer, id.kind(), id.archetypeId(), DEF_STATS),
                fallback
        );
    }

    private CombatDef effectiveCombat(Identity id) {
        CombatDef fallback = new CombatDef(1.0, 1.0, 8.0);

        return merger.merge(layer ->
                        defs.get(layer, id.kind(), id.archetypeId(), DEF_COMBAT),
                fallback
        );
    }

    private static double computeMaxHp(StatsDef statsDef, StatsState state) {
        return Math.max(1.0, 100.0 + (state.vit() * statsDef.hpPerVit()));
    }

    private static double clamp01(double v) {
        return v < 0 ? 0 : Math.min(1, v);
    }
}
