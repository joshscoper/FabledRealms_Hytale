package net.fabledrealms.ecs.runtime;

public enum RebuildPolicy {
    DERIVED_ONLY,   // recompute derived values, preserve volatile state (recommended default)
    RESET_STATE,    // rebuild and reset runtime state
    NO_ACTION
}
