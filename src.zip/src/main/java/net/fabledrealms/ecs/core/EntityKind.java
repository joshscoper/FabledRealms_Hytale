package net.fabledrealms.ecs.core;

public enum EntityKind {
    PLAYER,
    CHARACTER,
    NPC,
    MOB
}
