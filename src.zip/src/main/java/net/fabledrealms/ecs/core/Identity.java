package net.fabledrealms.ecs.core;

import java.util.UUID;

public record Identity(
        EntityKind kind,
        UUID entityId,          // the runtime entity UUID you use for addressing
        String archetypeId,     // e.g. "mob.dawn_boar", "npc.blacksmith", "class.mage"
        String instanceId       // optional stable ID for placed NPCs etc (string is friendly for tooling)
) {
    public static Identity of(EntityKind kind, UUID entityId, String archetypeId) {
        return new Identity(kind, entityId, archetypeId, null);
    }
}
