package net.fabledrealms.ecs.def;

public enum DefLayer {
    BASE,       // global defaults
    KIND,       // PLAYER/CHARACTER/NPC/MOB defaults
    ARCHETYPE,  // "mob.dawn_boar"
    ZONE,       // zone overrides
    INSTANCE,   // per-instance patch
    TEMP        // temporary definition-level overrides (events)
}
