package net.fabledrealms.ecs.def;

import net.fabledrealms.ecs.core.EntityKind;

import java.util.Optional;

public interface DefinitionRegistry {

    <T> Optional<T> get(DefLayer layer, EntityKind kind, String archetypeId, DefKey<T> key);

    /**
     * Convenience: return the best effective definition by merging layers.
     * You can implement this via a DefMerger (below).
     */
    <T> T effective(EntityKind kind, String archetypeId, DefKey<T> key, T fallback);
}
