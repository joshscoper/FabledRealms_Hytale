package net.fabledrealms.ecs.def;

import java.util.Objects;

public final class DefKey<T> {
    private final String id;
    private final Class<T> type;

    private DefKey(String id, Class<T> type) {
        this.id = Objects.requireNonNull(id);
        this.type = Objects.requireNonNull(type);
    }

    public static <T> DefKey<T> of(String id, Class<T> type) {
        return new DefKey<>(id, type);
    }

    public String id() { return id; }
    public Class<T> type() { return type; }
}
