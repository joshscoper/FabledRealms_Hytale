package net.fabledrealms.ecs.def;

import java.util.List;
import java.util.Optional;

public final class DefMerger {

    private final List<DefLayer> order;

    public DefMerger(List<DefLayer> order) {
        this.order = List.copyOf(order);
    }

    public <T> T merge(java.util.function.Function<DefLayer, Optional<T>> lookup, T fallback) {
        T cur = fallback;
        for (DefLayer layer : order) {
            Optional<T> v = lookup.apply(layer);
            if (v.isPresent()) {
                cur = v.get();
            }
        }
        return cur;
    }
}
