package net.fabledrealms.service;

import java.util.HashMap;
import java.util.Map;

public final class ServiceRegistry {

    private final Map<Class<?>, Object> services = new HashMap<>();

    public <T> void register(Class<T> type, T instance) {
        services.put(type, instance);
    }

    public <T> T require(Class<T> type) {
        Object v = services.get(type);
        if (v == null) throw new IllegalStateException("Missing service: " + type.getName());
        return type.cast(v);
    }

    public <T> T get(Class<T> type) {
        Object v = services.get(type);
        return v == null ? null : type.cast(v);
    }
}
